#!/usr/bin/env python3
# vibeisland.app -> 这个文件来源:siameseisland.app(MIT 友好克隆)
# Codex CLI lifecycle event bridge.
#
# Codex CLI 通过 ~/.codex/hooks.json 注册 Python 钩子,这个脚本被
# Codex 进程内 import,把 Codex 自己的事件名 (`on_session_start` /
# `pre_tool_call` 等) 翻译成 SiameseBridge 期望的 CC 风格 hook 事件
# (SessionStart / PreToolUse / PostToolUse / Stop) 通过 stdin 喂给
# Bridge,Bridge 走 Unix socket 把事件交给 SiameseIsland 主 app。
#
# Bridge 路径默认 ~/.siameseisland/bin/SiameseBridge,主 app 启动时
# symlink 到打包内的真二进制。
import json
import os
import subprocess

_BRIDGE = os.path.expanduser("~/.siameseisland/bin/SiameseBridge")


def _send(event_name, **kwargs):
    """Pipe a CC-shaped hook event to SiameseBridge --source codex."""
    if not os.path.isfile(_BRIDGE):
        return
    payload = {"hook_event_name": event_name}
    payload.update(kwargs)
    try:
        subprocess.run(
            [_BRIDGE, "--source", "codex"],
            input=json.dumps(payload).encode("utf-8"),
            capture_output=True,
            timeout=5,
        )
    except Exception:
        # 永不抛异常 —— 失败就静默,绝不挡住 Codex 主流程
        pass


# ------- Codex 事件 → CC 事件 名映射 -------

def _on_session_start(session_id="", **kw):
    _send("SessionStart",
          session_id=session_id,
          cwd=os.getcwd())


def _on_session_end(session_id="", **kw):
    _send("Stop", session_id=session_id)


def _on_tool_call(tool_name="", session_id="", **kw):
    _send("PreToolUse",
          session_id=session_id,
          tool_name=tool_name)
    # Codex 期待 dict 返回值表"是否放行";SI 默认放行,审批走 socket 异步
    return {"action": "allow"}


def _after_tool_call(tool_name="", session_id="", **kw):
    _send("PostToolUse",
          session_id=session_id,
          tool_name=tool_name)


# ------- Codex 注册入口 -------

def register(ctx):
    """Codex calls this on plugin load."""
    ctx.register_hook("on_session_start", _on_session_start)
    ctx.register_hook("on_session_end", _on_session_end)
    ctx.register_hook("pre_tool_call", _on_tool_call)
    ctx.register_hook("post_tool_call", _after_tool_call)
