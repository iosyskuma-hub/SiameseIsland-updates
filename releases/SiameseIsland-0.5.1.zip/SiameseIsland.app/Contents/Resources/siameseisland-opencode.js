// SiameseIsland — OpenCode lifecycle bridge plugin.
// Mounted at ~/.config/opencode/plugins/siameseisland.js by OpenCodeHookInstaller.
//
// OpenCode 用 ~/.config/opencode/opencode.json 的 plugins 数组加载这个文件,
// 默认导出函数收 { client, serverUrl }。client.event.subscribe(...) 拿到
// 全量事件流,我们把它翻成 CC 风格 hook event 然后 spawn SiameseBridge
// 把 JSON 喂 stdin。session_id 强制加 "opencode-" 前缀,主 app 那头按 cli
// 字段路由到对应 SiameseSession,brand mark 自动用 OpenAIMark(OpenCode 跟
// OpenAI 视觉一致)。
//
// 设计原则:任何错误都吞掉,绝不影响 OpenCode 主流程。spawn 超时 5s。

import { execSync } from "child_process";
import { homedir } from "os";
import { join } from "path";

const BRIDGE = join(homedir(), ".siameseisland", "bin", "SiameseBridge");

function send(payload) {
  try {
    const json = JSON.stringify(payload);
    // execSync 阻塞但 OpenCode 事件回调本身是异步事件,5s 超时足够;
    // 用 pipe stdio 把 input 喂进去,丢弃 stdout/stderr。
    execSync(`"${BRIDGE}" --source opencode`, {
      input: json,
      timeout: 5000,
      stdio: ["pipe", "ignore", "ignore"],
    });
  } catch {
    // 静默 — 失败可能是 SI 没运行,我们绝不挡 OpenCode
  }
}

// OpenCode 插件入口
export default async ({ client }) => {
  // 缓存 sessionId → cwd,后续事件不一定带 cwd 但需要(SI 用 cwd 推 projectName)
  const sessionCwd = new Map();
  // 缓存 sessionId → 最近一次 tool 名,PostToolUse 没带名字时兜底
  const lastTool = new Map();

  if (!client?.event?.subscribe) {
    // 旧版 OpenCode 没 event API,直接退出
    return;
  }

  client.event.subscribe(({ type, properties: p }) => {
    if (!p) return;

    // ---- Session lifecycle ----

    if (type === "session.created" && p.info?.id) {
      const cwd = p.info.directory || process.cwd();
      sessionCwd.set(p.info.id, cwd);
      send({
        hook_event_name: "SessionStart",
        session_id: `opencode-${p.info.id}`,
        cwd,
        cli: "opencode",
      });
      return;
    }

    if (type === "session.deleted" && p.info?.id) {
      send({
        hook_event_name: "Stop",
        session_id: `opencode-${p.info.id}`,
        cli: "opencode",
      });
      sessionCwd.delete(p.info.id);
      lastTool.delete(p.info.id);
      return;
    }

    // ---- Tool calls (走 message.part.updated, part.type === 'tool') ----

    if (
      type === "message.part.updated" &&
      p.part?.type === "tool" &&
      p.part?.sessionID
    ) {
      const sid = p.part.sessionID;
      const cwd = sessionCwd.get(sid);
      const toolName = p.part.tool || lastTool.get(sid) || "";
      lastTool.set(sid, toolName);

      // OpenCode 的 part.state.status: "pending" | "running" | "completed" | "error"
      // pending/running → PreToolUse(用户可能要审批)
      // completed/error → PostToolUse
      const status = p.part.state?.status;
      const phase =
        status === "completed" || status === "error"
          ? "PostToolUse"
          : "PreToolUse";

      send({
        hook_event_name: phase,
        session_id: `opencode-${sid}`,
        cwd,
        tool_name: toolName,
        cli: "opencode",
      });
      return;
    }

    // ---- Permission asked → PreToolUse with approval intent ----

    if (type === "permission.asked" && p.id && p.sessionID) {
      const cwd = sessionCwd.get(p.sessionID);
      send({
        hook_event_name: "PreToolUse",
        session_id: `opencode-${p.sessionID}`,
        cwd,
        tool_name: p.metadata?.tool || "(permission)",
        _opencode_request_id: p.id,
        cli: "opencode",
      });
      return;
    }

    // ---- Question asked → PreToolUse(AskUserQuestion 工具) ----

    if (type === "question.asked" && p.id && p.sessionID) {
      const cwd = sessionCwd.get(p.sessionID);
      send({
        hook_event_name: "PreToolUse",
        session_id: `opencode-${p.sessionID}`,
        cwd,
        tool_name: "AskUserQuestion",
        tool_input: { questions: p.questions || [] },
        _opencode_request_id: p.id,
        cli: "opencode",
      });
      return;
    }
  });
};
